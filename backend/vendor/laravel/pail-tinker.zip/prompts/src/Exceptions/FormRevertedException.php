<?php

namespace Laravel\Prompts\Exceptions;

use RuntimeException;

class FormRevertedException extends RuntimeException
{
    //
}
